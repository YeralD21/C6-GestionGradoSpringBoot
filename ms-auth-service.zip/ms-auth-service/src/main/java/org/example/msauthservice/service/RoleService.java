package org.example.msauthservice.service;

public class RoleService {
}
